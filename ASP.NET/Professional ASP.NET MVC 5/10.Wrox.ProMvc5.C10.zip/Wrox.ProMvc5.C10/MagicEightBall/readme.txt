This example is posted on NuGet as "MagicEightBall"

Install-Package MagicEightBall